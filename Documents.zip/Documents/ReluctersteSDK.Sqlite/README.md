# ReluctersteSDK.Sqlite

基于 `Microsoft.Data.Sqlite` 的极简 ORM，提供**两套互不干扰的用法**：

| 模式 | 入口 | 适用场景 |
|---|---|---|
| 特性映射 | `SqliteDataBase` + `[DbTable]` / `[DbKey]` / `[DbColumn]` | 有固定实体类、强类型查询 |
| 纯行模式（RowMod） | `RowDbContext` / `RowTable` / `RowQuery` | 动态表、快速原型、schema 未定 |

数据库结构演进使用 `db.Migrations`：版本化、事务化、可回滚，详见场景六与
[API/Migrations.md](API/Migrations.md)。

- 目录：`ReluctersteSDK.Sqlite/`
- 包 ID：`ReluctersteSDK.Sqlite`
- 命名空间：`ReluctersteSDK.Sqlite` / `.RowMod`
- 依赖：`ReluctersteSDK.Paths`、`Microsoft.Data.Sqlite`

---

## 场景一：建库并打开

```csharp
using ReluctersteSDK.Sqlite;

var db = new SqliteDataBase(@"E:\Data\App", "app.db");   // folderPath, databaseName
await db.EnsureInitializedAsync();                        // 幂等，只初始化一次
```

构造时就会创建目录。`EnsureInitializedAsync` 设置：

```sql
PRAGMA busy_timeout = 5000;
PRAGMA foreign_keys = ON;
PRAGMA journal_mode = WAL;        -- enableWal: true 时
PRAGMA synchronous = NORMAL;
```

也可以传 `FdPath`：

```csharp
using ReluctersteSDK.Paths;

var db = new SqliteDataBase(new RelativePath(@"Data\Databases"), "app.db");
```

---

## 场景二：定义实体，然后增删改查

**只有标了 `[DbKey]` 或 `[DbColumn]` 的属性才会入库**——没标的直接忽略，不需要 `[DbIgnore]`。

```csharp
using ReluctersteSDK.Sqlite;

[DbTable("players")]
public class PlayerRow
{
    [DbKey("id")]         public long Id { get; set; }
    [DbColumn("name")]    public string Name { get; set; } = "";
    [DbColumn("score")]   public int Score { get; set; }
    [DbColumn("created")] public DateTime Created { get; set; }

    public string RuntimeOnly { get; set; } = "";   // 不入库
}
```

```csharp
await db.EnsureTableAsync<PlayerRow>();     // CREATE TABLE IF NOT EXISTS

await db.InsertAsync(new PlayerRow { Id = 1, Name = "A", Score = 10 });
await db.UpsertAsync(new PlayerRow { Id = 1, Name = "A", Score = 20 });   // ON CONFLICT DO UPDATE
await db.UpdateAsync(new PlayerRow { Id = 1, Name = "A", Score = 30 });   // 按主键更新非键列

PlayerRow? one = await db.GetByKeyAsync<PlayerRow>(1);        // 找不到返回 null

List<PlayerRow> many = await db.QueryAsync<PlayerRow>(
    where: "score > @min",
    parameters: new { min = 15 },
    orderBy: "score DESC",
    limit: 10);

await db.DeleteByKeyAsync<PlayerRow>(1);
```

实体类需要**公共无参构造函数**（`QueryAsync<T>` 有 `where T : new()` 约束）。

---

## 场景三：写原生 SQL

```csharp
await db.ExecuteAsync("UPDATE players SET score = score + 1 WHERE id = @id", new { id = 1 });

object? count = await db.ExecuteScalarAsync("SELECT COUNT(*) FROM players");

List<string> names = await db.QuerySqlAsync(
    "SELECT name FROM players",
    reader => reader.GetString(0));
```

`QuerySqlAsync` 的第二个参数是**行投影委托**，你想映射成什么类型都行：

```csharp
var pairs = await db.QuerySqlAsync(
    "SELECT name, score FROM players",
    r => (Name: r.GetString(0), Score: r.GetInt32(1)));
```

---

## 场景四：不想写实体类

**目标**：表结构在运行期才知道，或者只是临时脚本。

```csharp
using ReluctersteSDK.Sqlite.RowMod;

await using var ctx = new RowDbContext(db);
RowTable users = ctx["users"];

await users.CreateTableIfNotExistsAsync(
    ("id",    "INTEGER PRIMARY KEY AUTOINCREMENT"),
    ("name",  "TEXT NOT NULL"),
    ("age",   "INTEGER"));

await users.AddAsync(new Row { ["name"] = "Alice", ["age"] = 25 });
await users.AddRangeAsync(new[] { /* 多条，单事务 */ });

long total = await users.CountAsync();
List<Row> all = await users.ToListAsync();
```

`Row` 是**列名忽略大小写**的字典，取值得自己转型：

```csharp
Row? alice = await users.Where(r => r.Get<string>("name") == "Alice").FirstOrDefaultAsync();
int age = alice!.Get<int>("age");     // 走 ORM 的类型转换
```

---

## 场景五：表达式查询 + 批量更新/删除

```csharp
await users
    .Where(r => r.Get<int>("age") >= 18 && r.Get<string>("email")!.Contains("gmail"))
    .OrderByDescending("age")
    .Skip(10)
    .Take(2)
    .ToListAsync();

await users.Where(r => r.Get<int>("age") < 18).DeleteAsync();
await users.Where(r => r.Get<string>("name") == "Alice")
           .UpdateAsync(new Row { ["age"] = 26 });
```

表达式翻译**只支持**：比较（`== != > >= < <=`）、逻辑（`&& || !`）、`r.Get<T>("col")`、`r["col"]`、`string.Contains("x")`。其它表达式会 `Compile()` 后当参数求值。

---

## 场景六：数据库迁移

**目标**：已经上线的库要加字段 / 建索引，且需要记录执行历史、失败可回滚。

```csharp
using ReluctersteSDK.Sqlite.Migrations;

SqliteMigration[] migrations =
{
    SqliteMigration.Create(1, "创建 players 表", async (context, ct) =>
    {
        await context.CreateTableIfNotExistsAsync<PlayerRow>(ct);
    }),

    SqliteMigration.Create(
        2,
        "增加 score 列",
        up: async (context, ct) =>
        {
            await context.AddColumnAsync(
                "players", "score", "INTEGER",
                defaultValueSql: "0",
                cancellationToken: ct);
        },
        down: async (context, ct) =>
        {
            await context.DropColumnAsync("players", "score", ct);
        })
};

MigrationResult result = await db.Migrations.MigrateAsync(migrations);
Console.WriteLine($"执行 {result.AppliedCount} 个，当前版本 {result.CurrentVersion}");
```

- 每个迁移在独立事务中执行，失败整体回滚且不写历史；
- 已执行的版本自动跳过，重复启动安全；
- 版本号必须递增；已到 3 之后再补版本 2 会抛异常（不支持乱序迁移）；
- `RollbackAsync(migrations, targetVersion: 1)` 按版本降序回滚；
- 不写子类时用 `SqliteMigration.Create`，需要可回滚时提供 `down`。

详见 [API/Migrations.md](API/Migrations.md)。

---

## API 文档

| 文档 | 内容 |
|---|---|
| [API/SqliteDataBase.md](API/SqliteDataBase.md) | 构造、初始化、原生 SQL、类型映射、并发与连接模型 |
| [API/AttributeMapping.md](API/AttributeMapping.md) | `[DbTable]` / `[DbKey]` / `[DbColumn]` / `[DbIgnore]` 与 CRUD 方法 |
| [API/Migrations.md](API/Migrations.md) | 版本化迁移：历史表、升级/回滚、DDL 助手、异常与限制 |
| [API/RowMod.md](API/RowMod.md) | `RowDbContext`、`RowTable`、`RowQuery`、`Row` 与表达式支持范围 |
