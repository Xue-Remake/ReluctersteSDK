# ReluctersteSDK.Game

面向 **2D 游戏**的 ECS 框架：实体 / 组件 / 系统、父子层级与变换、查询与调度、单例、精灵渲染、帧动画、摄像机裁剪、快照与调试统计。

- 目录：`ReluctersteSDK.Game/`
- 包 ID：`ReluctersteSDK.Game`
- 命名空间：`ReluctersteSDK.Game.Ecs` / `.Ecs.Events` / `.Systems` / `.Rendering`
- 依赖：`ReluctersteSDK.Math`、`MonoGame.Framework.DesktopGL`

> **2D 硬约束**：只用 2D 向量 + 单轴旋转 + `Matrix3x2`。不提供 `Quaternion`、3D 相机、透视投影。
> 需要 3D 请另建独立包，不要往这里加维度开关。

> 完整设计蓝图见 **[ECS-设计.md](ECS-设计.md)**。

---

## 场景一：跑起来一个最小世界

**目标**：一个实体、一个系统、每帧更新。

```csharp
using ReluctersteSDK.Game.Ecs;
using ReluctersteSDK.Game.Systems;
using ReluctersteSDK.Math.Vectors;

var world = new World();

Entity player = world.Create();
world.Add(player, Transform.Identity);

world.AddSystem(new MotionSystem());      // 先推进位置
world.AddSystem(new TransformSystem());   // 再算世界矩阵

// Game.Update
world.Update((float)gameTime.ElapsedGameTime.TotalSeconds);
```

**同一阶段内按优先级升序执行，优先级相同按注册顺序。** 对大多数游戏，Update 阶段的系统顺序是：

```
逻辑系统 → MotionSystem → TransformSystem → SpriteAnimationSystem
```

```csharp
world.AddSystem(new MotionSystem(), SystemPhase.Update, priority: -10);
world.AddSystem(new TransformSystem());   // priority 默认 0
```

`TransformSystem` 必须在所有改 `Transform.LocalPosition` 的逻辑之后、所有读 `WorldTransform` 的渲染之前。

---

## 场景二：让玩家动起来

**目标**：按键给加速度，松手靠阻尼停下来。

```csharp
using Microsoft.Xna.Framework.Input;
using ReluctersteSDK.Math.Vectors;

Entity player = world.Create();
world.Add(player, Transform.Identity);
world.Add(player, new Velocity());
world.Add(player, new Acceleration());
world.Add(player, new Damping { Coefficient = 6f, MaxSpeed = 240f });

// 每帧读输入，写加速度
world.Get<Acceleration>(player).Value = CartesianVector2D.Zero;

KeyboardState kb = Keyboard.GetState();
if (kb.IsKeyDown(Keys.D)) world.Get<Acceleration>(player).Value += new CartesianVector2D(900, 0);
if (kb.IsKeyDown(Keys.A)) world.Get<Acceleration>(player).Value += new CartesianVector2D(-900, 0);
if (kb.IsKeyDown(Keys.W)) world.Get<Acceleration>(player).Value += new CartesianVector2D(0, -900);
if (kb.IsKeyDown(Keys.S)) world.Get<Acceleration>(player).Value += new CartesianVector2D(0, 900);
```

`MotionSystem` 每帧的顺序是：**先更新速度**（加速度 → 阻尼 → 限速），**再用新速度推进位置**。

想直接设速度（比如传送、冲刺）就跳过 `Acceleration`，直接写 `Velocity.Value`。

---

## 场景三：武器跟随角色

**目标**：子实体跟着父实体走。

```csharp
Entity body = world.Create();
world.Add(body, Transform.Identity);

Entity sword = world.Create();
world.Add(sword, new Transform
{
    LocalPosition = new CartesianVector2D(16, 4),
    LocalRotation = 0f,
    LocalScale = CartesianVector2D.One,
});

world.SetParent(sword, body);     // 双向维护 + 成环检测
```

之后 `TransformSystem` 会算出 `sword.WorldTransform = local * body.WorldTransform`，渲染时直接用。

**必须用 `SetParent` / `RemoveParent`**：`Parent` 与 `Children` 是双向数据，手工只改一侧会不一致。

```csharp
world.GetParent(sword);            // Entity.Null 表示无父
world.GetChildren(body);           // IReadOnlyList<Entity>
world.IsInAncestorChain(child, ancestor);
```

> 自环、成环会被拒绝（返回 `false`）；换父会自动从旧父的子列表摘除。
> **销毁父节点时子节点保留并升级为根**，不会级联销毁。

---

## 场景四：画一个精灵

**目标**：把一个纹理画到实体位置。

```csharp
using ReluctersteSDK.Game.Rendering;

var sprite = new Sprite(texture)
{
    Layer = 10,
    Depth = 0f,
    Origin = new Vector2(texture.Width / 2f, texture.Height / 2f),   // 以中心为锚点
};
world.Add(player, sprite);

var renderSystem = new SpriteRenderSystem();
world.AddSystem(renderSystem, SystemPhase.Render);
```

```csharp
// Game.Draw
world.Render(deltaTime);

spriteBatch.Begin(samplerState: SamplerState.PointClamp, sortMode: SpriteSortMode.Deferred);
renderSystem.Submit(spriteBatch);
spriteBatch.End();
```

排序规则：**Layer 升序 → Depth 升序 → 纹理 → 实体索引**。最后一层保证同层同深度的帧间稳定（不闪烁）。

> `Submit` 内部已经排好序，`Begin` **必须用 `SpriteSortMode.Deferred`**；
> 换成按纹理排序会被 SpriteBatch 重排，层序失效。

---

## 场景五：播放帧动画

**目标**：一张序列图，一套 idle / run / attack。

```csharp
using Microsoft.Xna.Framework;
using ReluctersteSDK.Game.Rendering;

Rectangle[] idleFrames = SpriteSheet.Slice(texture, 16, 16, columns: 3, frameCount: 2);
Rectangle[] runFrames  = SpriteSheet.Slice(texture, 16, 16, startIndex: 3, frameCount: 6);

var idle = new AnimationClip("idle", idleFrames, frameDuration: 0.25f, loop: true);
var run  = new AnimationClip("run",  runFrames,  frameDuration: 0.10f, loop: true);

var animator = new Animator(idle, run);
world.Add(player, animator);
world.Add(player, new Sprite(texture));

world.AddSystem(new SpriteAnimationSystem());               // 必须在 SpriteRenderSystem 之前
```

```csharp
animator.Play("run");                 // 切到 run
animator.Play("run", restart: true);  // 强制从头播
animator.Speed = 2f;
```

非循环动画播完后 `IsPlaying` 变 `false`，但**当前帧停在最后一帧**，精灵不会消失：

```csharp
if (animator.FinishedClip == "attack")
    animator.Play("idle");
```

> `FinishedClip` / `FrameChanged` **只在调用 `Tick` 的那一帧内有效**，下一帧开头会被清空。
> 因此消费它们的系统必须排在 `SpriteAnimationSystem` 之后。

---

## 场景六：遍历时销毁实体

**目标**：血量归零的敌人当场删掉。

```csharp
world.Query<Health>().ForEach((Entity e, ref Health h) =>
{
    if (h.Value <= 0)
        world.Commands.Destroy(e);      // 记成命令，不当场改结构
});

world.Update(dt);   // 每个系统执行后自动回放
```

**遍历中禁止增删实体 / 组件**，会立即抛 `InvalidOperationException`（由 `StructuralVersion` 校验）。

两条合法路径：

```csharp
// 方式一：命令缓冲（推荐，执行时机确定）
world.Commands.Destroy(e);

// 方式二：先取快照
foreach (Entity e in world.Query<Health>().ToEntityArray()) { /* 可以随意改结构 */ }
```

命令缓冲在**每个系统执行完之后**回放，因此下一个系统能看到上一个系统的修改。

---

## 场景七：多组件查询与排除

```csharp
// 三/四组件交集
world.Query<Transform, Velocity, Health>().ForEach((Entity e, ref Transform t, ref Velocity v, ref Health h) => { });

// 排除同时持有 Dead 的实体
world.Query<Health>().Without<Dead>().ForEach((Entity e, ref Health h) => { });

// 链式排除
world.Query<Transform, Sprite>().Without<Hidden>().Without<Destroyed>();
```

查询仍会校验结构版本：遍历期间增删实体/组件会抛 `InvalidOperationException`。

---

## 场景八：系统阶段、优先级与启停

```csharp
world.AddSystem(new InputSystem(), SystemPhase.Update, priority: -100);
world.AddSystem(new MotionSystem(), SystemPhase.Update, priority: 0);
world.AddSystem(new TransformSystem(), SystemPhase.Update, priority: 10);
world.AddSystem(new LateCameraSystem(), SystemPhase.LateUpdate);
world.AddSystem(new SpriteRenderSystem(), SystemPhase.Render);

world.SetSystemEnabled(inputSystem, false);   // 临时禁用
world.Start();                                 // 执行 Startup + 所有 OnStart
world.Update(dt);                              // Update → LateUpdate
world.Render(dt);                              // Render
world.Shutdown();                              // Teardown + 所有 OnStop
```

`ISystem` 提供默认的 `OnStart` / `OnStop`，现有系统无需改动。

---

## 场景九：单例、生命周期事件与释放

```csharp
world.SetSingleton(new GameTimeState { Elapsed = 0f });
ref GameTimeState state = ref world.GetSingleton<GameTimeState>();

world.EntityCreated += e => Console.WriteLine($"created {e}");
world.ComponentAdded += e => Console.WriteLine($"added {e.ComponentType.Name}");

world.Clear();      // 复位但继续使用；触发 WorldCleared
world.Dispose();    // 释放；之后公开操作抛 ObjectDisposedException
```

---

## 场景十：摄像机与裁剪

```csharp
var camera = new Camera2D
{
    Position = playerPosition,
    Zoom = 2f
};
camera.Resize(graphicsDevice.Viewport.Width, graphicsDevice.Viewport.Height);

renderSystem.Camera = camera;
renderSystem.CullingEnabled = true;

world.Render(dt);
Console.WriteLine($"本帧裁剪 {renderSystem.LastCulledCount} 个精灵");
```

`ViewBounds` 提供世界空间的可见 AABB；`WorldToScreen` / `ScreenToWorld` 可做拾取。

---

## 场景十一：快照

```csharp
var registry = ComponentCodecRegistry.CreateDefault();
registry.Register<Health>();          // 自定义纯数据组件
registry.Register<Inventory>();

WorldSnapshot snapshot = WorldSnapshotSerializer.Capture(world, registry);

using var stream = File.Create("save.json");
WorldSnapshotSerializer.Save(world, stream, registry);
```

恢复：

```csharp
using var stream = File.OpenRead("save.json");
WorldSnapshotSerializer.Load(targetWorld, stream, registry);
```

快照保存实体 Index/Generation 与已注册组件；`Children` 由 `Parent` 重建，`WorldTransform` 由 `TransformSystem` 重算。`Sprite`、`Animator`、纹理等运行时资源不参与。

---

## 场景十二：调试统计

```csharp
world.StatisticsEnabled = true;
world.Update(dt);
world.Render(dt);

WorldStats stats = world.GetStats();
Console.WriteLine($"entities={stats.EntityCount}, components={stats.ComponentCount}");
foreach (SystemTiming timing in world.SystemTimings)
    Console.WriteLine($"{timing.SystemName}: {timing.Milliseconds:F3} ms");
```

---

## 场景十三：系统之间传事件

**目标**：战斗系统算出的伤害，让死亡系统去处理，但不要在遍历中改结构。

```csharp
using ReluctersteSDK.Game.Ecs.Events;

public readonly record struct DamageDealt(Entity Attacker, Entity Target, int Amount);

// 产生（Update 阶段）
world.Events.Raise(new DamageDealt(attacker, target, dealt));

// 消费（下一帧任意阶段）
foreach (ref readonly DamageDealt e in world.Events.Read<DamageDealt>())
{
    if (world.IsAlive(e.Target) && world.Get<Health>(e.Target).Value <= 0)
        world.Commands.Destroy(e.Target);
}
```

三条规则：

- **第 N 帧登记，第 N+1 帧可读**（`World.Update` 在开头自动交换缓冲）
- **遍历中继续 `Raise` 是安全的** —— 写的是另一个缓冲
- **事件类型就是队列**，定义个 `record struct` 即可，没有注册步骤

事件不进快照、不跨线程、不做委托订阅。需要广播给 UI / 存档时，在应用层桥接到独立的事件总线。

> 完整语义与注意事项见 **[API/Events.md](API/Events.md)**。

---

## API 文档

| 文档 | 内容 |
|---|---|
| [API/Entity.md](API/Entity.md) | `Entity`、`EntityManager`、`ComponentStore<T>`、`IComponentStore` |
| [API/World.md](API/World.md) | `World`、`Query<T…>`、`Without`、`SystemEntry`、单例、事件、`CommandBuffer` |
| [API/Components.md](API/Components.md) | `Transform`、`Parent` / `Children` / `WorldTransform`、`Velocity` / `Acceleration` / `Damping` / `Heading` |
| [API/Systems.md](API/Systems.md) | `TransformSystem`、`MotionSystem`、系统阶段/优先级/启停 |
| [API/Rendering.md](API/Rendering.md) | `Sprite`、`RenderCommand`、`SpriteRenderSystem`、`MonoGameInterop` |
| [API/Camera.md](API/Camera.md) | `Camera2D`：世界/屏幕转换、可见范围、缩放旋转 |
| [API/Animation.md](API/Animation.md) | `AnimationFrame`、`AnimationClip`、`Animator`、`SpriteSheet`、`SpriteAnimationSystem` |
| [API/Snapshots.md](API/Snapshots.md) | `WorldSnapshot`、`ComponentCodecRegistry`、`WorldSnapshotSerializer` |
| [API/Events.md](API/Events.md) | `WorldEvents`、`EventQueue<T>`、双缓冲交换语义 |
| [API/Diagnostics.md](API/Diagnostics.md) | `WorldStats`、`ComponentStoreStats`、`SystemTiming` |
| [API/EventLogger.md](API/EventLogger.md) | `EventLogger`、`LogEventAttribute`（与 ECS 无关的控制台日志） |
| [ECS-设计.md](ECS-设计.md) | 设计稿：分层原则、为什么这么选、已知取舍 |
